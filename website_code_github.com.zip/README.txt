# WEBSITE CODE EXTRACTIONS REPORT 

Website: https://github.com/dashboard
EXTRACTION DATE: 1433268.764744304

## Summary:
- HTML FILES: 1
- CSS FILES: 13
- INLINE CSS BLOCKS: 1
- JAVASCRIPT FILES: 41
- INLINE JAVASCRIPT BLOCKS: 4
- API ENDPOINTS FOUND: 1
- IMAGES FOUND: 0

## Files Structure:
- index.html (Main HTML file)
- css/ (All CSS files)
- js/ (All JavaScript files)
- api_endpoints.txt (List of found API endpoints)

## Note:
This extraction includes all publicly accessible code from the website.
Some dynamic content loaded via AJAX may not be included.
